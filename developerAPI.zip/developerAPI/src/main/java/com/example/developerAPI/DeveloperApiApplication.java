package com.example.developerAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeveloperApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeveloperApiApplication.class, args);
	}

}
